function output = SeamCarve(input, widthFac, heightFac, mask)

% Main seam carving function. This is done in three main parts: 1)
% computing the energy function, 2) finding optimal seam, and 3) removing
% the seam. The three parts are repeated until the desired size is reached.

assert(widthFac == 1 || heightFac == 1, 'Changing both width and height is not supported!');
assert(widthFac <= 1 && heightFac <= 1, 'Increasing the size is not supported!');


output = imresize(input, [heightFac*size(input, 1) widthFac*size(input, 2)]);
